# Skillset-Based-Recommendation-System

this Project will help you with recommanding group of similar skillsets 
the calucation is based on Euclidean distance score

discussed as below !

## Euclidean distance 

In mathematics, the Euclidean distance between two points in Euclidean space is the length of a line segment between the two points. It can be calculated from the Cartesian coordinates of the points using the Pythagorean theorem, therefore occasionally being called the Pythagorean distance.

![Screenshot 2021-08-03 at 8 38 24 PM](https://user-images.githubusercontent.com/57908107/128039573-fb29ef62-2650-43da-b95f-a252824267f4.png)

## Tech Stack 

  - Python3.x
  - Flask
  - HTML
  - CSS
  - JavaScript
  - CSV & JSON ( data-set Files )

By : Nilesh Hadalgi AKA Techie Programmer

Project Screen Shot
![ezgif com-gif-maker (1)](https://user-images.githubusercontent.com/57908107/128044191-9e51a4b5-a26a-48d4-9535-33abb646e3c0.gif)
